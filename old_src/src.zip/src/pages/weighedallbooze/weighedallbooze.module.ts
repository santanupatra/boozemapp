import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { WeighedallboozePage } from './weighedallbooze';

@NgModule({
  declarations: [
    WeighedallboozePage,
  ],
  imports: [
    IonicPageModule.forChild(WeighedallboozePage),
  ],
})
export class WeighedallboozePageModule {}
