import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UtaliaztionReportPage } from './utaliaztion-report';

@NgModule({
  declarations: [
    UtaliaztionReportPage,
  ],
  imports: [
    IonicPageModule.forChild(UtaliaztionReportPage),
  ],
})
export class UtaliaztionReportPageModule {}
