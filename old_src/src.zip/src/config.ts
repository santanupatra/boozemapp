
export const Config = {
    baseUrl:'http://111.93.169.90/team6/boozemap/api/'
}