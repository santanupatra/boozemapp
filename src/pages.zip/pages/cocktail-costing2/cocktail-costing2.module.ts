import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CocktailCosting2Page } from './cocktail-costing2';

@NgModule({
  declarations: [
    CocktailCosting2Page,
  ],
  imports: [
    IonicPageModule.forChild(CocktailCosting2Page),
  ],
})
export class CocktailCosting2PageModule {}
